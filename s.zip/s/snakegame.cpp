#include "snakegame.h"
#include <QPainter>
#include <QPen>
#include <QBrush>
#include <QFont>
#include <QMessageBox>
#include <QDebug>

SnakeGame::SnakeGame(QWidget *parent)
    : QWidget(parent), direction(Right), nextDirection(Right), gameState(Ready),
    score(0), level(1), speed(150), timeElapsed(0)
{
    setWindowTitle("炫彩贪吃蛇");
    setFixedSize(500, 600);
    setFocusPolicy(Qt::StrongFocus);

    // 创建阴影效果
    shadowEffect = new QGraphicsDropShadowEffect(this);
    shadowEffect->setBlurRadius(15);
    shadowEffect->setColor(QColor(0, 0, 0, 160));
    shadowEffect->setOffset(4, 4);

    // 主菜单容器
    mainMenuWidget = new QWidget(this);
    mainMenuWidget->setGeometry(50, 50, 400, 500);
    mainMenuWidget->setStyleSheet(
        "background-color: white;"
        "border-radius: 15px;"
        "padding: 20px;"
        );
    mainMenuWidget->setGraphicsEffect(shadowEffect);

    // 主布局
    QVBoxLayout *mainLayout = new QVBoxLayout(mainMenuWidget);
    mainLayout->setAlignment(Qt::AlignCenter);
    mainLayout->setSpacing(30);

    // 欢迎标签
    welcomeLabel = new QLabel("炫彩贪吃蛇");
    welcomeLabel->setStyleSheet(
        "QLabel {"
        "   font-size: 36px;"
        "   font-weight: bold;"
        "   color: #2c3e50;"
        "}"
        );
    welcomeLabel->setAlignment(Qt::AlignCenter);

    // 游戏图标
    QLabel *iconLabel = new QLabel("🐍");
    iconLabel->setStyleSheet("font-size: 72px;");
    iconLabel->setAlignment(Qt::AlignCenter);

    // 游戏说明
    instructionsLabel = new QLabel(
        "使用方向键控制蛇的移动\n\n"
        "吃掉苹果增长身体\n"
        "达到满屏进入下一关\n"
        "共5个关卡，速度逐渐增加"
        );
    instructionsLabel->setStyleSheet(
        "QLabel {"
        "   font-size: 16px;"
        "   color: #7f8c8d;"
        "   line-height: 1.5;"
        "}"
        );
    instructionsLabel->setAlignment(Qt::AlignCenter);

    // 按钮容器
    QWidget *buttonContainer = new QWidget();
    QVBoxLayout *buttonLayout = new QVBoxLayout(buttonContainer);
    buttonLayout->setSpacing(15);
    buttonLayout->setContentsMargins(50, 0, 50, 0);

    // 开始按钮
    startButton = new QPushButton("开始游戏");
    startButton->setFixedHeight(50);
    startButton->setStyleSheet(
        "QPushButton {"
        "   background-color: #3498db;"
        "   color: white;"
        "   font-size: 18px;"
        "   font-weight: bold;"
        "   border-radius: 10px;"
        "   padding: 10px;"
        "}"
        "QPushButton:hover {"
        "   background-color: #2980b9;"
        "}"
        );

    // 退出按钮
    exitButton = new QPushButton("退出游戏");
    exitButton->setFixedHeight(50);
    exitButton->setStyleSheet(
        "QPushButton {"
        "   background-color: #e74c3c;"
        "   color: white;"
        "   font-size: 18px;"
        "   font-weight: bold;"
        "   border-radius: 10px;"
        "   padding: 10px;"
        "}"
        "QPushButton:hover {"
        "   background-color: #c0392b;"
        "}"
        );

    // 添加到布局
    buttonLayout->addWidget(startButton);
    buttonLayout->addWidget(exitButton);

    mainLayout->addWidget(welcomeLabel);
    mainLayout->addWidget(iconLabel);
    mainLayout->addWidget(instructionsLabel);
    mainLayout->addStretch();
    mainLayout->addWidget(buttonContainer);

    // 连接信号槽
    connect(startButton, &QPushButton::clicked, this, &SnakeGame::startGame);
    connect(exitButton, &QPushButton::clicked, this, &QWidget::close);

    // 初始化游戏UI
    initGameUI();
    hideGameUI();

    // 初始化游戏
    initGame();

    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &SnakeGame::updateGame);
}

SnakeGame::~SnakeGame()
{
}

void SnakeGame::initGameUI()
{
    // 游戏信息面板
    QWidget *infoPanel = new QWidget(this);
    infoPanel->setObjectName("infoPanel");
    infoPanel->setGeometry(0, 0, width(), 60);
    infoPanel->setStyleSheet("background-color: #34495e;");

    QHBoxLayout *infoLayout = new QHBoxLayout(infoPanel);
    infoLayout->setContentsMargins(20, 0, 20, 0);

    // 分数标签
    scoreLabel = new QLabel("分数: 0");
    scoreLabel->setStyleSheet("color: white; font-size: 16px;");

    // 时间标签
    timeLabel = new QLabel("时间: 0秒");
    timeLabel->setStyleSheet("color: white; font-size: 16px;");

    // 等级标签
    levelLabel = new QLabel("等级: 1");
    levelLabel->setStyleSheet("color: white; font-size: 16px;");

    infoLayout->addWidget(scoreLabel);
    infoLayout->addStretch();
    infoLayout->addWidget(timeLabel);
    infoLayout->addStretch();
    infoLayout->addWidget(levelLabel);

    // 游戏结束标签
    gameOverLabel = new QLabel("游戏结束!");
    gameOverLabel->setAlignment(Qt::AlignCenter);
    gameOverLabel->setStyleSheet(
        "QLabel {"
        "   color: #e74c3c;"
        "   font-weight: bold;"
        "   font-size: 24px;"
        "   background-color: rgba(255, 255, 255, 0.8);"
        "   border-radius: 10px;"
        "   padding: 20px;"
        "}"
        );
    gameOverLabel->setGeometry(width()/2-150, height()/2-50, 300, 100);
    gameOverLabel->hide();

    gameCompleteLabel = new QLabel("恭喜通关!");
    gameCompleteLabel->setAlignment(Qt::AlignCenter);
    gameCompleteLabel->setStyleSheet(
        "QLabel {"
        "   color: #2ecc71;"
        "   font-weight: bold;"
        "   font-size: 24px;"
        "   background-color: rgba(255, 255, 255, 0.8);"
        "   border-radius: 10px;"
        "   padding: 20px;"
        "}"
        );
    gameCompleteLabel->setGeometry(width()/2-150, height()/2-50, 300, 100);
    gameCompleteLabel->hide();

    // 重新开始按钮
    QPushButton *restartButton = new QPushButton("重新开始", this);
    restartButton->setObjectName("restartButton");
    restartButton->setGeometry(width()/2-75, height()/2+70, 150, 40);
    restartButton->setStyleSheet(
        "QPushButton {"
        "   background-color: #3498db;"
        "   color: white;"
        "   font-size: 16px;"
        "   border-radius: 5px;"
        "}"
        "QPushButton:hover {"
        "   background-color: #2980b9;"
        "}"
        );
    connect(restartButton, &QPushButton::clicked, this, &SnakeGame::startGame);
    restartButton->hide();

    // 计算游戏区域位置
    gameAreaTop = 80;
    gameAreaLeft = (width() - GRID_SIZE * CELL_SIZE) / 2;
}

void SnakeGame::hideGameUI()
{
    mainMenuWidget->show();
    findChild<QWidget*>("infoPanel")->hide();
    gameOverLabel->hide();
    gameCompleteLabel->hide();
    findChild<QPushButton*>("restartButton")->hide();
}

void SnakeGame::showGameUI()
{
    mainMenuWidget->hide();
    findChild<QWidget*>("infoPanel")->show();
    gameOverLabel->hide();
    gameCompleteLabel->hide();
    findChild<QPushButton*>("restartButton")->hide();
}

void SnakeGame::initGame()
{
    snake.clear();
    snake.append(QPoint(GRID_SIZE / 2, GRID_SIZE / 2));
    generateApple();
    direction = Right;
    nextDirection = Right;
    score = 0;
    timeElapsed = 0;
    level = 1;
    speed = 150;
    gameState = Ready;
    updateScore();
}

void SnakeGame::startGame()
{
    initGame();
    showGameUI();
    gameState = Playing;
    gameTimer.start();
    timer->start(speed);
    setFocus();
}

void SnakeGame::gameOver()
{
    gameState = GameOver;
    timer->stop();
    gameOverLabel->show();
    findChild<QPushButton*>("restartButton")->show();
    update();
}

void SnakeGame::nextLevel()
{
    if (level < MAX_LEVEL) {
        level++;
        speed -= 20;
        snake.clear();
        snake.append(QPoint(GRID_SIZE / 2, GRID_SIZE / 2));
        generateApple();
        direction = Right;
        nextDirection = Right;
        gameState = Playing;
        timer->setInterval(speed);
        updateScore();
    } else {
        gameState = GameComplete;
        timer->stop();
        gameCompleteLabel->show();
        findChild<QPushButton*>("restartButton")->show();
        update();
    }
}

void SnakeGame::updateGame()
{
    if (gameState != Playing) return;

    timeElapsed = gameTimer.elapsed() / 1000;
    timeLabel->setText(QString("时间: %1秒").arg(timeElapsed));

    if (nextDirection != None) {
        direction = nextDirection;
    }

    moveSnake();
    checkCollision();
    update();
}

void SnakeGame::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    if (gameState == Ready) return;

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    // 绘制游戏区域背景
    painter.fillRect(gameAreaLeft, gameAreaTop,
                     GRID_SIZE * CELL_SIZE, GRID_SIZE * CELL_SIZE,
                     QColor("#ecf0f1"));

    // 绘制游戏区域边框
    painter.setPen(QPen(QColor("#34495e"), 2));
    painter.drawRect(gameAreaLeft, gameAreaTop,
                     GRID_SIZE * CELL_SIZE, GRID_SIZE * CELL_SIZE);

    drawGrid(painter);
    drawApple(painter);
    drawSnake(painter);
}

void SnakeGame::drawGrid(QPainter &painter)
{
    painter.setPen(QPen(QColor("#bdc3c7"), 1));

    for (int i = 0; i <= GRID_SIZE; ++i) {
        // 横线
        painter.drawLine(gameAreaLeft, gameAreaTop + i * CELL_SIZE,
                         gameAreaLeft + GRID_SIZE * CELL_SIZE, gameAreaTop + i * CELL_SIZE);
        // 竖线
        painter.drawLine(gameAreaLeft + i * CELL_SIZE, gameAreaTop,
                         gameAreaLeft + i * CELL_SIZE, gameAreaTop + GRID_SIZE * CELL_SIZE);
    }
}

void SnakeGame::drawSnake(QPainter &painter)
{
    QColor snakeColor;
    switch (level) {
    case 1: snakeColor = QColor("#3498db"); break;
    case 2: snakeColor = QColor("#2980b9"); break;
    case 3: snakeColor = QColor("#16a085"); break;
    case 4: snakeColor = QColor("#8e44ad"); break;
    case 5: snakeColor = QColor("#c0392b"); break;
    default: snakeColor = QColor("#3498db");
    }

    painter.setBrush(snakeColor);
    painter.setPen(Qt::NoPen);

    for (const QPoint &point : snake) {
        QRect rect(
            gameAreaLeft + point.x() * CELL_SIZE + 1,
            gameAreaTop + point.y() * CELL_SIZE + 1,
            CELL_SIZE - 1, CELL_SIZE - 1
            );
        painter.drawRect(rect);
    }

    // 绘制蛇头
    if (!snake.isEmpty()) {
        painter.setBrush(QColor("#f1c40f"));
        QRect headRect(
            gameAreaLeft + snake.first().x() * CELL_SIZE + 1,
            gameAreaTop + snake.first().y() * CELL_SIZE + 1,
            CELL_SIZE - 1, CELL_SIZE - 1
            );
        painter.drawRect(headRect);
    }
}

void SnakeGame::drawApple(QPainter &painter)
{
    painter.setBrush(QColor("#e74c3c"));
    painter.setPen(Qt::NoPen);
    QRect appleRect(
        gameAreaLeft + apple.x() * CELL_SIZE + 1,
        gameAreaTop + apple.y() * CELL_SIZE + 1,
        CELL_SIZE - 1, CELL_SIZE - 1
        );
    painter.drawEllipse(appleRect);
}

void SnakeGame::moveSnake()
{
    if (direction == None) return;

    QPoint head = snake.first();
    QPoint newHead = head;

    switch (direction) {
    case Up:    newHead.ry()--; break;
    case Down:  newHead.ry()++; break;
    case Left:  newHead.rx()--; break;
    case Right: newHead.rx()++; break;
    }

    snake.prepend(newHead);
    snake.removeLast();
}

void SnakeGame::checkCollision()
{
    QPoint head = snake.first();

    // 检查是否撞墙
    if (head.x() < 0 || head.x() >= GRID_SIZE ||
        head.y() < 0 || head.y() >= GRID_SIZE) {
        gameOver();
        return;
    }

    // 检查是否撞到自己
    for (int i = 1; i < snake.size(); ++i) {
        if (head == snake.at(i)) {
            gameOver();
            return;
        }
    }

    // 检查是否吃到苹果
    if (head == apple) {
        // 增加蛇的长度
        QPoint tail = snake.last();
        snake.append(tail);

        // 更新分数
        score += level * 10;
        updateScore();

        // 检查是否填满整个格子
        if (snake.size() >= GRID_SIZE * GRID_SIZE) {
            nextLevel();
            return;
        }

        // 生成新的苹果
        generateApple();
    }
}

void SnakeGame::generateApple()
{
    QList<QPoint> possiblePositions;

    for (int y = 0; y < GRID_SIZE; ++y) {
        for (int x = 0; x < GRID_SIZE; ++x) {
            QPoint point(x, y);
            if (!isSnake(x, y)) {
                possiblePositions.append(point);
            }
        }
    }

    if (possiblePositions.isEmpty()) {
        nextLevel();
        return;
    }

    int index = QRandomGenerator::global()->bounded(possiblePositions.size());
    apple = possiblePositions.at(index);
}

bool SnakeGame::isSnake(int x, int y)
{
    QPoint point(x, y);
    return snake.contains(point);
}

void SnakeGame::updateScore()
{
    scoreLabel->setText(QString("分数: %1").arg(score));
    levelLabel->setText(QString("等级: %1").arg(level));
}

void SnakeGame::keyPressEvent(QKeyEvent *event)
{
    if (gameState != Playing) {
        QWidget::keyPressEvent(event);
        return;
    }

    switch (event->key()) {
    case Qt::Key_Up:
    case Qt::Key_W:
        if (direction != Down)
            nextDirection = Up;
        break;
    case Qt::Key_Down:
    case Qt::Key_S:
        if (direction != Up)
            nextDirection = Down;
        break;
    case Qt::Key_Left:
    case Qt::Key_A:
        if (direction != Right)
            nextDirection = Left;
        break;
    case Qt::Key_Right:
    case Qt::Key_D:
        if (direction != Left)
            nextDirection = Right;
        break;
    default:
        QWidget::keyPressEvent(event);
    }

    event->accept();
}

void SnakeGame::resizeEvent(QResizeEvent *event)
{
    gameAreaLeft = (width() - GRID_SIZE * CELL_SIZE) / 2;
    QWidget::resizeEvent(event);
}

QPoint SnakeGame::gridToScreen(const QPoint &gridPos) const
{
    return QPoint(
        gameAreaLeft + gridPos.x() * CELL_SIZE,
        gameAreaTop + gridPos.y() * CELL_SIZE
        );
}
