#include "snakegame.h"
#include <QPainter>
#include <QPen>
#include <QBrush>
#include <QFont>
#include <QMessageBox>
#include <QDebug>

SnakeGame::SnakeGame(QWidget *parent)
    : QWidget(parent), direction(Right), nextDirection(Right), gameState(Ready),
    score(0), level(1), speed(150), timeElapsed(0)
{
    setWindowTitle("贪吃的doro");
    setFixedSize(500, 600);
    setFocusPolicy(Qt::StrongFocus);

    // 创建阴影效果
    shadowEffect = new QGraphicsDropShadowEffect(this);
    shadowEffect->setBlurRadius(25);
    shadowEffect->setColor(QColor(0, 0, 0, 200));
    shadowEffect->setOffset(6, 6);

    QPixmap bgPixmap(":/new/prefix1/picture/doro3.png");
    if (!bgPixmap.isNull()) {
        menuBgSize = bgPixmap.size();
    } else {
        menuBgSize = QSize(400, 500); // 默认尺寸
        qWarning() << "Failed to load menu background image";
    }

    // 主菜单容器
    mainMenuWidget = new QWidget(this);
    mainMenuWidget->setFixedSize(menuBgSize);
    mainMenuWidget->setStyleSheet(QString(
        "QWidget {"
        "   background: url(:/new/prefix1/picture/doro3.png) center/contain no-repeat;"
        "   border: none;"
        "}"
        ));

    mainMenuWidget->setGraphicsEffect(shadowEffect);

    // 主布局
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(mainMenuWidget, 0, Qt::AlignCenter);
    mainLayout->setAlignment(Qt::AlignCenter);
    mainLayout->setSpacing(30);

    // 欢迎标签
    welcomeLabel = new QLabel("贪吃的doro",mainMenuWidget);
    welcomeLabel->setStyleSheet(
        "QLabel {"
        "   font-size: 42px;"        // 放大字号
        "   font-weight: bold;"
        "   color: #ffffff;"         // 改为白色
        "   text-shadow: 1px 1px 3px rgba(0,0,0,0.5);" // 添加文字阴影
        "}"
        );

    welcomeLabel->setAlignment(Qt::AlignCenter);


    // 游戏说明
    instructionsLabel = new QLabel ("使用方向键控制doro的移动\n"
                                   "吃掉耄耋增长身体\n"
                                   "达到满屏进入下一关\n"
                                   "共5个关卡，速度逐渐增加",mainMenuWidget);
    instructionsLabel->setStyleSheet(
        "QLabel {"
        "   font-size: 16px;"
        "   color: #7f8c8d;"
        "   line-height: 1.5;"
        "}"
        );
    instructionsLabel->setAlignment(Qt::AlignCenter);

    // 按钮容器
    QWidget *buttonContainer = new QWidget();
    QVBoxLayout *buttonLayout = new QVBoxLayout(buttonContainer);
    buttonLayout->setSpacing(15);
    buttonLayout->setContentsMargins(50, 0, 50, 0);

    // 开始按钮
    startButton = new QPushButton("开始游戏");
    startButton->setFixedHeight(50);
    startButton->setStyleSheet(
        "QPushButton {"
        "   background-color: #3498db;"
        "   color: white;"
        "   font-size: 18px;"
        "   font-weight: bold;"
        "   border-radius: 10px;"
        "   padding: 10px;"
        "}"
        "QPushButton:hover {"
        "   background-color: #2980b9;"
        "}"
        );

    // 退出按钮
    exitButton = new QPushButton("退出游戏");
    exitButton->setFixedHeight(50);
    exitButton->setStyleSheet(
        "QPushButton {"
        "   background-color: #e74c3c;"
        "   color: white;"
        "   font-size: 18px;"
        "   font-weight: bold;"
        "   border-radius: 10px;"
        "   padding: 10px;"
        "}"
        "QPushButton:hover {"
        "   background-color: #c0392b;"
        "}"
        );

    // 添加到布局
    buttonLayout->addWidget(startButton);
    buttonLayout->addWidget(exitButton);

    mainLayout->addWidget(welcomeLabel);
    mainLayout->addWidget(instructionsLabel);
    mainLayout->addStretch();
    mainLayout->addWidget(buttonContainer);

    // 连接信号槽
    connect(startButton, &QPushButton::clicked, this, &SnakeGame::startGame);
    connect(exitButton, &QPushButton::clicked, this, &QWidget::close);

    // 初始化游戏UI
    initGameUI();
    hideGameUI();

    // 初始化游戏
    initGame();

    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &SnakeGame::updateGame);
    // 加载图片资源
    if (!headPixmap.load(":/new/prefix1/picture/doro.png")) {
        QMessageBox::critical(this, "Error", "Failed to load snake head image");
    }
    if (!bodyPixmap.load(":/new/prefix1/picture/doro.png")) {
        QMessageBox::critical(this, "Error", "Failed to load snake body image");
    }
    if (!applePixmap.load(":/new/prefix1/picture/mao.png")) {
        QMessageBox::critical(this, "Error", "Failed to load apple image");
    }
    // 调整图片大小
    headPixmap = headPixmap.scaled(CELL_SIZE, CELL_SIZE, Qt::KeepAspectRatio);
    bodyPixmap = bodyPixmap.scaled(CELL_SIZE, CELL_SIZE, Qt::KeepAspectRatio);
    applePixmap = applePixmap.scaled(CELL_SIZE, CELL_SIZE, Qt::KeepAspectRatio);
    // 创建各方向蛇头图片（如果需要不同方向的图片）
    headPixmaps[Right] = headPixmap;
    headPixmaps[Left] = headPixmap.transformed(QTransform().rotate(180));
    headPixmaps[Up] = headPixmap.transformed(QTransform().rotate(-90));
    headPixmaps[Down] = headPixmap.transformed(QTransform().rotate(90));
}

SnakeGame::~SnakeGame()
{
}

void SnakeGame::initGameUI()
{
    // 游戏信息面板
    QWidget *infoPanel = new QWidget(this);
    infoPanel->setObjectName("infoPanel");
    infoPanel->setGeometry(0, 0, width(), 60);
    infoPanel->setStyleSheet("background-color: #34495e;");

    QHBoxLayout *infoLayout = new QHBoxLayout(infoPanel);
    infoLayout->setContentsMargins(20, 0, 20, 0);

    // 分数标签
    scoreLabel = new QLabel("分数: 0");
    scoreLabel->setStyleSheet("color: white; font-size: 16px;");

    // 时间标签
    timeLabel = new QLabel("时间: 0秒");
    timeLabel->setStyleSheet("color: white; font-size: 16px;");

    // 等级标签
    levelLabel = new QLabel("等级: 1");
    levelLabel->setStyleSheet("color: white; font-size: 16px;");

    infoLayout->addWidget(scoreLabel);
    infoLayout->addStretch();
    infoLayout->addWidget(timeLabel);
    infoLayout->addStretch();
    infoLayout->addWidget(levelLabel);

    // 游戏结束标签
    gameOverLabel = new QLabel("游戏结束!");
    gameOverLabel->setAlignment(Qt::AlignCenter);
    gameOverLabel->setStyleSheet(
        "QLabel {"
        "   color: #e74c3c;"
        "   font-weight: bold;"
        "   font-size: 24px;"
        "   background-color: rgba(255, 255, 255, 0.8);"
        "   border-radius: 10px;"
        "   padding: 20px;"
        "}"
        );
    gameOverLabel->setGeometry(width()/2-150, height()/2-50, 300, 100);
    gameOverLabel->hide();

    gameCompleteLabel = new QLabel("恭喜通关!");
    gameCompleteLabel->setAlignment(Qt::AlignCenter);
    gameCompleteLabel->setStyleSheet(
        "QLabel {"
        "   color: #2ecc71;"
        "   font-weight: bold;"
        "   font-size: 24px;"
        "   background-color: rgba(255, 255, 255, 0.8);"
        "   border-radius: 10px;"
        "   padding: 20px;"
        "}"
        );
    gameCompleteLabel->setGeometry(width()/2-150, height()/2-50, 300, 100);
    gameCompleteLabel->hide();

    // 重新开始按钮
    QPushButton *restartButton = new QPushButton("重新开始", this);
    restartButton->setObjectName("restartButton");
    restartButton->setGeometry(width()/2-75, height()/2+70, 150, 40);
    restartButton->setStyleSheet(
        "QPushButton {"
        "   background-color: #3498db;"
        "   color: white;"
        "   font-size: 16px;"
        "   border-radius: 5px;"
        "}"
        "QPushButton:hover {"
        "   background-color: #2980b9;"
        "}"
        );
    connect(restartButton, &QPushButton::clicked, this, &SnakeGame::startGame);
    restartButton->hide();

    // 计算游戏区域位置
    gameAreaTop = 80;
    gameAreaLeft = (width() - GRID_SIZE * CELL_SIZE) / 2;

}

void SnakeGame::hideGameUI()
{
    mainMenuWidget->show();
    findChild<QWidget*>("infoPanel")->hide();
    gameOverLabel->hide();
    gameCompleteLabel->hide();
    findChild<QPushButton*>("restartButton")->hide();
}

void SnakeGame::showGameUI()
{
    mainMenuWidget->hide();
    findChild<QWidget*>("infoPanel")->show();
    gameOverLabel->hide();
    gameCompleteLabel->hide();
    findChild<QPushButton*>("restartButton")->hide();
}

void SnakeGame::initGame()
{
    snake.clear();
    snake.append(QPoint(GRID_SIZE / 2, GRID_SIZE / 2));
    generateApple();
    direction = Right;
    nextDirection = Right;
    score = 0;
    timeElapsed = 0;
    level = 1;
    speed = 150;
    gameState = Ready;
    updateScore();
}

void SnakeGame::startGame()
{
    initGame();
    showGameUI();
    gameState = Playing;
    gameTimer.start();
    timer->start(speed);
    setFocus();
}

void SnakeGame::gameOver()
{
    gameState = GameOver;
    timer->stop();
    gameOverLabel->show();
    findChild<QPushButton*>("restartButton")->show();
    update();
}

void SnakeGame::nextLevel()
{
    if (level < MAX_LEVEL) {
        level++;
        speed -= 20;
        snake.clear();
        snake.append(QPoint(GRID_SIZE / 2, GRID_SIZE / 2));
        generateApple();
        direction = Right;
        nextDirection = Right;
        gameState = Playing;
        timer->setInterval(speed);
        updateScore();
    } else {
        gameState = GameComplete;
        timer->stop();
        gameCompleteLabel->show();
        findChild<QPushButton*>("restartButton")->show();
        update();
    }
}

void SnakeGame::updateGame()
{
    if (gameState != Playing) return;

    timeElapsed = gameTimer.elapsed() / 1000;
    timeLabel->setText(QString("时间: %1秒").arg(timeElapsed));

    if (nextDirection != None) {
        direction = nextDirection;
    }

    moveSnake();
    checkCollision();
    update();
}

void SnakeGame::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    if (gameState == Ready) return;

    QPainter painter(this);
    painter.setRenderHint(QPainter::SmoothPixmapTransform); // 启用平滑缩放

    // 绘制游戏区域背景
    painter.fillRect(gameAreaLeft, gameAreaTop,
                     GRID_SIZE * CELL_SIZE, GRID_SIZE * CELL_SIZE,
                     QColor("#ecf0f1"));

    // 绘制游戏区域边框
    painter.setPen(QPen(QColor("#34495e"), 2));
    painter.drawRect(gameAreaLeft, gameAreaTop,
                     GRID_SIZE * CELL_SIZE, GRID_SIZE * CELL_SIZE);

    drawGrid(painter);
    drawApple(painter);
    drawSnake(painter);
}

void SnakeGame::drawGrid(QPainter &painter)
{
    painter.setPen(QPen(QColor("#bdc3c7"), 1));

    for (int i = 0; i <= GRID_SIZE; ++i) {
        // 横线
        painter.drawLine(gameAreaLeft, gameAreaTop + i * CELL_SIZE,
                         gameAreaLeft + GRID_SIZE * CELL_SIZE, gameAreaTop + i * CELL_SIZE);
        // 竖线
        painter.drawLine(gameAreaLeft + i * CELL_SIZE, gameAreaTop,
                         gameAreaLeft + i * CELL_SIZE, gameAreaTop + GRID_SIZE * CELL_SIZE);
    }
}

void SnakeGame::drawSnake(QPainter &painter)
{
    QColor snakeColor;
    // 绘制身体
    for (int i = 1; i < snake.size(); ++i) {
        QPoint pos = gridToScreen(snake[i]);
        painter.drawPixmap(pos.x(), pos.y(), bodyPixmap);
    }

    // 绘制蛇头
    if (!snake.isEmpty()) {
        QPoint pos = gridToScreen(snake.first());
        painter.drawPixmap(pos.x(), pos.y(), headPixmaps[direction]);
    }
}

void SnakeGame::drawApple(QPainter &painter)
{
    QPoint pos = gridToScreen(apple);
    painter.drawPixmap(pos.x(), pos.y(), applePixmap);
}

QPoint SnakeGame::gridToScreen(const QPoint &gridPos) const
{
    return QPoint(
        gameAreaLeft + gridPos.x() * CELL_SIZE,
        gameAreaTop + gridPos.y() * CELL_SIZE
        );
}

void SnakeGame::moveSnake()
{
    if (direction == None) return;

    QPoint head = snake.first();
    QPoint newHead = head;

    switch (direction) {
    case Up:    newHead.ry()--; break;
    case Down:  newHead.ry()++; break;
    case Left:  newHead.rx()--; break;
    case Right: newHead.rx()++; break;
    }

    snake.prepend(newHead);
    snake.removeLast();
}

void SnakeGame::checkCollision()
{
    QPoint head = snake.first();

    // 检查是否撞墙
    if (head.x() < 0 || head.x() >= GRID_SIZE ||
        head.y() < 0 || head.y() >= GRID_SIZE) {
        gameOver();
        return;
    }

    // 检查是否撞到自己
    for (int i = 1; i < snake.size(); ++i) {
        if (head == snake.at(i)) {
            gameOver();
            return;
        }
    }

    // 检查是否吃到苹果
    if (head == apple) {
        // 增加蛇的长度
        QPoint tail = snake.last();
        snake.append(tail);

        // 更新分数
        score += level * 10;
        updateScore();

        // 检查是否填满整个格子
        if (snake.size() >= GRID_SIZE * GRID_SIZE) {
            nextLevel();
            return;
        }

        // 生成新的苹果
        generateApple();
    }
}

void SnakeGame::generateApple()
{
    QList<QPoint> possiblePositions;

    for (int y = 0; y < GRID_SIZE; ++y) {
        for (int x = 0; x < GRID_SIZE; ++x) {
            QPoint point(x, y);
            if (!isSnake(x, y)) {
                possiblePositions.append(point);
            }
        }
    }

    if (possiblePositions.isEmpty()) {
        nextLevel();
        return;
    }

    int index = QRandomGenerator::global()->bounded(possiblePositions.size());
    apple = possiblePositions.at(index);
}

bool SnakeGame::isSnake(int x, int y)
{
    QPoint point(x, y);
    return snake.contains(point);
}

void SnakeGame::updateScore()
{
    scoreLabel->setText(QString("分数: %1").arg(score));
    levelLabel->setText(QString("等级: %1").arg(level));
}

void SnakeGame::keyPressEvent(QKeyEvent *event)
{
    if (gameState != Playing) {
        QWidget::keyPressEvent(event);
        return;
    }

    switch (event->key()) {
    case Qt::Key_Up:
    case Qt::Key_W:
        if (direction != Down)
            nextDirection = Up;
        break;
    case Qt::Key_Down:
    case Qt::Key_S:
        if (direction != Up)
            nextDirection = Down;
        break;
    case Qt::Key_Left:
    case Qt::Key_A:
        if (direction != Right)
            nextDirection = Left;
        break;
    case Qt::Key_Right:
    case Qt::Key_D:
        if (direction != Left)
            nextDirection = Right;
        break;
    default:
        QWidget::keyPressEvent(event);
    }

    event->accept();
}

void SnakeGame::resizeEvent(QResizeEvent *event)
{
    gameAreaLeft = (width() - GRID_SIZE * CELL_SIZE) / 2;
    QWidget::resizeEvent(event);
}
