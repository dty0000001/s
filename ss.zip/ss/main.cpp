#include "snakegame.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication
        a(argc, argv);

    // 设置应用程序样式
    QApplication::setStyle("Fusion");

    // 创建并显示游戏窗口
    SnakeGame game
        ;
    game
        .show();

    return a.exec();
}
