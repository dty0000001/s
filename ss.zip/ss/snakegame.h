#ifndef SNAKEGAME_H
#define SNAKEGAME_H

#include <QWidget>
#include <QKeyEvent>
#include <QTimer>
#include <QLabel>
#include <QPushButton>
#include <QGridLayout>
#include <QElapsedTimer>
#include <QGraphicsDropShadowEffect>
#include <QRandomGenerator>
#include <QMediaPlayer>
#include <QAudioOutput>


class SnakeGame : public QWidget
{
    Q_OBJECT

public:
    SnakeGame(QWidget *parent = nullptr);
    ~SnakeGame();

protected:
    void paintEvent(QPaintEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

private slots:
    void startGame();
    void gameOver();
    void nextLevel();
    void updateGame();

private:
    enum Direction { None, Up, Down, Left, Right };
    enum GameState { Ready, Playing, GameOver, LevelComplete, GameComplete };

    void initGame();
    void initGameUI();
    void showGameUI();
    void hideGameUI();
    void drawSnake(QPainter &painter);
    void drawApple(QPainter &painter);
    void drawGrid(QPainter &painter);
    void moveSnake();
    void checkCollision();
    void generateApple();
    bool isSnake(int x, int y);
    void updateScore();
    QPoint gridToScreen(const QPoint &gridPos) const;

    static const int GRID_SIZE = 20;
    static const int CELL_SIZE = 20;
    static const int MAX_LEVEL = 5;

    QTimer *timer;
    QList<QPoint> snake;
    QPoint apple;
    Direction direction;
    Direction nextDirection;
    GameState gameState;
    int score;
    int level;
    int speed;
    int timeElapsed;
    QElapsedTimer gameTimer;

    // 游戏区域位置
    int gameAreaTop;
    int gameAreaLeft;

    // UI元素
    QLabel *welcomeLabel;
    QLabel *instructionsLabel;
    QLabel *scoreLabel;
    QLabel *timeLabel;
    QLabel *levelLabel;
    QLabel *gameOverLabel;
    QLabel *gameCompleteLabel;
    QPushButton *startButton;
    QPushButton *exitButton;
    QWidget *mainMenuWidget;
    QWidget *gameWidget;
    QGraphicsDropShadowEffect *shadowEffect;
    QPixmap headPixmap;
    QPixmap bodyPixmap;
    QPixmap applePixmap;
    QMap<Direction, QPixmap> headPixmaps;
    QSize menuBgSize;
    QMediaPlayer *bgmPlayer;
    QAudioOutput *audioOutput;
};

#endif // SNAKEGAME_H
